<?php

if(empty($_SESSION['user'])){
    include_once("View/login.view.php");
} else {
    if($_SESSION['user']->login() === true){
        include_once("View/home.view.php");
    } else {
        include_once("View/login.view.php");
    }
}