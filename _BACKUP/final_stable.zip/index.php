<?php

require_once('Model/Autoloader.php');
Autoloader::register();

session_start();

Database::createConnexion();

if(isset($_POST) and !empty($_POST)) {
    foreach($_POST as $key => $value) {
        $_POST[$key] = htmlentities($value);
    }
}

if(!empty($_GET['page'])) {
    $page = strtolower($_GET['page']);
} else {
    $page = 'home';
}

if(is_file("Controller/".$page."controller.php")) {
    require_once("Controller/".$page."controller.php");
} else {
    if($page == "process-login") {
        require_once("Controller/login.controller.php");
    } elseif($page == "process-register") {
        require_once("Controller/register.controller.php");
    } elseif($page == "process-logout") {
        require_once("Controller/logout.controller.php");
    } elseif($page == "process-map") {
        require_once("Controller/map.controller.php");
    } elseif($page == "start-game") {
        require_once("Controller/game.controller.php");
    } elseif($page == "next-turn") {
        require_once("Controller/game.controller.php");
    } elseif($page == "select-box") {
        require_once("Controller/game.controller.php");
    } elseif($page == "build-tower") {
        require_once("Controller/game.controller.php");
    } elseif($page == "sell-tower") {
        require_once("Controller/game.controller.php");
    } else {
        require_once("Controller/home.controller.php");
    }
}

