<?php

$main = '<form action="?page=next-turn" method="post">
    <input type="submit" name="submit" value="next_turn">
</form>';

$tower = '<form action="?page=build-tower" method="post">
<button type="submit" name="type" value="arrow">Build_arrow_tower</button>
<button type="submit" name="type" value="fire">Build_fire_tower</button>
<button type="submit" name="type" value="lazer">Build_lazer_tower</button>
</form>

<form action="?page=start-game" method="post">
<button type="submit" name="cancel" value="cancel">CANCEL</button>
</form>';

if(isset($_POST['box'])) {
    echo $tower;
} else {
    echo $main;
}