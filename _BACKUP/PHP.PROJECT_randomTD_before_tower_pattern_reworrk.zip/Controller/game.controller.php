<?php

// echo "game controller<br>";
if(!empty($_SESSION['user'])) {

    if($page == "start-game" and isset($_SESSION['map'])) {
    
        $_SESSION['user']->destroyUI();
        $_SESSION['user']->destroyEnemies();
        $_SESSION['user']->destroyMap();
        $_SESSION['user']->destroyPathOrder();
        $_SESSION['user']->destroyTowers();
        
        $_SESSION['map']->saveMap();
        $_SESSION['map']->savePathOrder();
    
        $ui = new UI($_SESSION['user']->name);
        $ui->turn = 0;
        $ui->hp = 10;
        $ui->gold = 10;
        $ui->difficulty = 4;
        $ui->saveUI();

        unset($ui);
        unset($_SESSION['map']);
    
        require_once('View/game.view.php');
    
    } elseif($page == "start-game" and !isset($_SESSION['map'])) {
        
        if(!isset($ui)) {
            $ui = new UI($_SESSION['user']->name);
            $ui->loadUI();
            if(!$ui->findUI()) {
                require_once('View/map.view.php');
                exit;
            }
            if($ui->hp <= 0) {
                require_once('View/gameover.view.php');
                exit;
            }
        }

        require_once('View/game.view.php');
        
    } elseif($page == "next-turn") {
        
        $ui = new UI($_SESSION['user']->name);
        $ui->loadUI();
        $ui->nextTurn();
        
        foreach($_SESSION['user']->loadEnemies() as $value) {
            $enemy = new Enemy($value['user'], $value['attack_pt']);
            $enemy->health_pt = $value['health_pt'];
            $enemy->enemy_nb = $value['enemy_nb'];
            $enemy->path_pos = $value['path_pos'] + 1;
            $enemy->setCoord();
            $enemy->updateEnemy($value['id']);
            $enemy->attack($ui, count($_SESSION['user']->indexPathOrder()) - 1);
            unset($enemy);
        }

        if($ui->rollDice()) {
            $enemy = new Enemy($_SESSION['user']->name, 1);
            $enemy->storeEnemy();
            unset($enemy);
        }

        $ui->updateUI();

        if($ui->hp <= 0) {
            require_once('View/gameover.view.php');
            exit;
        }

        require_once('View/game.view.php');

    } elseif($page == "select-box" and isset($_POST['box'])) {
        $_SESSION['box_x'] = $_POST['box_x'];
        $_SESSION['box_y'] = $_POST['box_y'];
        require_once('View/game.view.php');
        
    } elseif($page == "select-box" and isset($_POST['tower'])) {
        $_SESSION['tower_x'] = $_POST['box_x'];
        $_SESSION['tower_y'] = $_POST['box_y'];
        // require_once('View/game.view.php');
        echo "hqilo";

    } elseif($page == "select-box" and (!isset($_POST['box']) or !isset($_POST['box']))) {
        require_once('View/game.view.php');

    } elseif($page == "build-tower" and isset($_POST['type'])) {

        $ui = new UI($_SESSION['user']->name);
        $ui->loadUI();

        // echo $_POST['type'];
        // echo $_SESSION['box_x'];
        // echo $_SESSION['box_y'];
        $tower = new Tower($_SESSION['user']->name, $_POST['type'], $_SESSION['box_x'], $_SESSION['box_y']);

        // ######################### GROS PB de conditionelle
        if(!$_SESSION['user']->indexTower() and $ui->gold > $tower->cost) {
            $tower->storeTower();
            require_once('View/game.view.php');
            // echo "build successful";
            exit;
        } else {
            foreach($_SESSION['user']->indexTower() as $value) {
                if($value['x'] == $tower->x and $value['y'] == $tower->y) {
                    require_once('View/game.view.php');
                    // echo "you can't build here";
                    exit;

                } elseif($ui->gold < $tower->cost) {
                    require_once('View/game.view.php');
                    // echo "not enough gold";
                    exit;
                } else {
                    $tower->storeTower();
                    require_once('View/game.view.php');
                    // echo "build successful";
                    exit;

                }
            }
        }

    } elseif($page == "build-tower" and !isset($_POST['type'])) {
        require_once('View/game.view.php');
    } else {
        header('location: index.php');
    }
    
} else {
    header('location: index.php');
}

//todo: 