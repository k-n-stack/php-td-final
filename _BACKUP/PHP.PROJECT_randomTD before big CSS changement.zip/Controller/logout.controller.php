<?php

if($page == "process-logout" and isset($_SESSION)) {
    $_SESSION['user']->destroyMap();
    unset($_SESSION);
    session_destroy();
    header("location: index.php");
    exit;
}
header("location: index.php");
exit;