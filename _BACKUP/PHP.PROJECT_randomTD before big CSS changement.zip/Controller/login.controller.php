<?php

if($page == "process-login" and isset($_POST)) {
    if(isset($_SESSION['login-error'])) {
        unset($_SESSION['login-error']);
    }
    if(isset($_SESSION['register-error'])) {
        unset($_SESSION['register-error']);
    }
    $user = new User($_POST['username'], $_POST['password']);
    $check = $user->login();
    if($check === true) {
        $_SESSION['user'] = $user;
        header('location: ?page=home');
        exit;
    } else {
        $_SESSION['login-error'] = $check;
    }
}

header('location: index.php');