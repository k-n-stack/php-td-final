<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="go.css">
    <title>Game Over</title>
</head>
<body id='go'>
    <div>
        <div id='goimg-box'>
            <img id='goimg' src=".\Img\go.png" width="500px" height="500px">
        </div>

        <div id='gomsg'>
            <p>Enemy Destroyed Your Home !</p>
            <a href="index.php">retour acceuil</a>
        </div>
    </div>
</body>
</html>