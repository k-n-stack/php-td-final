<?php

if($page == "process-register" and isset($_POST)) {
    if(isset($_SESSION['login-error'])) {
        unset($_SESSION['login-error']);
    }
    if(isset($_SESSION['register-error'])) {
        unset($_SESSION['register-error']);
    }
    var_dump($_POST);
    $user = new User($_POST['username'], $_POST['password'], $_POST['password_check']);
    $register = $user->register();
    if($register === true) {
        $_SESSION['user'] = $user;
        header('location: ?page=home');
        exit;
    } else {
        $_SESSION['register-error'] = $register;
    }
}
header("location: index.php");
exit;