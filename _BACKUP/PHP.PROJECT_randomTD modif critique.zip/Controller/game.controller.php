<?php

// echo "game controller<br>";
if(!empty($_SESSION['user'])) {

    if($page == "start-game" and isset($_SESSION['map'])) {
    
        $_SESSION['user']->destroyUI();
        $_SESSION['user']->destroyEnemies();
        $_SESSION['user']->destroyMap();
        $_SESSION['user']->destroyPathOrder();
        $_SESSION['user']->destroyTowers();
        
        $_SESSION['map']->saveMap();
        $_SESSION['map']->savePathOrder();
    
        $ui = new UI($_SESSION['user']->name);
        $ui->turn = 0;
        $ui->hp = 10;
        $ui->gold = 10;
        $ui->difficulty = 4;
        $ui->saveUI();

        unset($ui);
        unset($_SESSION['map']);
    
        require_once('View/game.view.php');
    
    } elseif($page == "start-game" and !isset($_SESSION['map'])) {
        
        if(!isset($ui)) {
            $ui = new UI($_SESSION['user']->name);
            $ui->loadUI();
            if(!$ui->findUI()) {
                require_once('View/map.view.php');
                exit;
            }
            if($ui->hp <= 0) {
                require_once('View/gameover.view.php');
                exit;
            }
        }

        require_once('View/game.view.php');
        
    } elseif($page == "next-turn") {
        
        $allEnemies = $_SESSION['user']->indexEnemies();
        $allTowers = $_SESSION['user']->indexTower();
        foreach($allTower as $tower) {
            $tower_o = new Tower($_SESSION['user']->name, $tower['t_type'], $tower['x'], $tower['y']);
            foreach($allEnemies as $enemy) {
                
            }
        }

        $ui = new UI($_SESSION['user']->name);
        $ui->loadUI();
        $ui->nextTurn();
        
        foreach($_SESSION['user']->loadEnemies() as $value) {
            $enemy = new Enemy($value['user'], $value['attack_pt']);
            $enemy->health_pt = $value['health_pt'];
            $enemy->enemy_nb = $value['enemy_nb'];
            $enemy->path_pos = $value['path_pos'] + 1;
            $enemy->setCoord();
            $enemy->updateEnemy($value['id']);
            $enemy->attack($ui, count($_SESSION['user']->indexPathOrder()) - 1);
            unset($enemy);
        }

        if($ui->rollDice()) {
            $enemy = new Enemy($_SESSION['user']->name, 1);
            $enemy->storeEnemy();
            unset($enemy);
        }

        $ui->updateUI();

        if($ui->hp <= 0) {
            require_once('View/gameover.view.php');
            exit;
        }

        require_once('View/game.view.php');

    #### add css for selected box
    } elseif($page == "select-box" and isset($_POST['box'])) {
        $_SESSION['box_x'] = $_POST['box_x'];
        $_SESSION['box_y'] = $_POST['box_y'];
        require_once('View/game.view.php');
        
        #### to do
    } elseif($page == "select-box" and isset($_POST['tower'])) {
        $_SESSION['tower_x'] = $_POST['box_x'];
        $_SESSION['tower_y'] = $_POST['box_y'];
        $_SESSION['type'] = $_POST['type'];
        require_once('View/game.view.php');

    } elseif($page == "build-tower" and isset($_POST['type'])) {

        $ui = new UI($_SESSION['user']->name);
        $ui->loadUI();

        // echo $_POST['type'];
        // echo $_SESSION['box_x'];
        // echo $_SESSION['box_y'];
        $tower = new Tower($_SESSION['user']->name, $_POST['type'], $_SESSION['box_x'], $_SESSION['box_y']);

        if($tower->towerExist()) {
            // echo "There is already a tower here!";
            require_once('View/game.view.php');
        } elseif(!$ui->canBuy($tower)) {
            // echo "Not enough money";
            require_once('View/game.view.php');
        } else {
            // echo "ok?";
            $tower->storeTower();
            $ui->gold -= $tower->cost;
            $ui->updateUI();

            require_once('View/game.view.php');
        }

    } elseif($page == "sell-tower" and isset($_POST['sell'])) {
        
        $ui = new UI($_SESSION['user']->name);
        $ui->loadUI();

        $tower = new Tower($_SESSION['user']->name, $_SESSION['type'], $_SESSION['tower_x'], $_SESSION['tower_y']);

        $ui->gold += $tower->sellAmount();
        $ui->updateUI();

        $tower->destroyTower();

        require_once('View/game.view.php');

    } else {
        header('location: index.php');
    }
    
} else {
    header('location: index.php');
}

//todo: revoir build tower
// ensuite bosser sur le pattern