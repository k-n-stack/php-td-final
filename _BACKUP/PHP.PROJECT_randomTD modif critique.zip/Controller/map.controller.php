<?php

if(!empty($_SESSION['user'])) {
    if($page == "process-map" and !empty($_POST)) {
        
        if(isset($_SESSION['login-error'])) {
            unset($_SESSION['login-error']);
        }
        if(isset($_SESSION['register-error'])) {
            unset($_SESSION['register-error']);
        }
        if(isset($_SESSION['map'])) {
            unset($_SESSION['map']);
        }

        if(!isset($_POST['x_length'])
        or !isset($_POST['y_length'])
        or intval($_POST['x_length']) < 10
        or intval($_POST['x_length']) > 20
        or intval($_POST['y_length']) < 10
        or intval($_POST['y_length']) > 20) {
            include_once("View/map.view.php");
            exit;
        } else {
            $map = new Map($_SESSION['user']->name, intval($_POST['x_length']), intval($_POST['y_length']));
            $_SESSION['map'] = $map;
            include_once("View/map.view.php");
            exit;
        }

        // echo '<pre>';
        // var_dump($map);
        // echo '</pre>';

    }
    include_once("View/map.view.php");
} else {
    header('location: index.php');
}