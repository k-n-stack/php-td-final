<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="main.style.css">
    <link rel="stylesheet" type="text/css" href="gamemap.style.css">
    <link rel="stylesheet" type="text/css" href="ui.style.css">
    <title>Document</title>
</head>
<body>

        <?php 
            if(isset($_POST['box_x']) and isset($_POST['box_x'])) {
                echo '<div class="boxselect-map">';
                include_once('boxselect.layout.view.php');
                echo '</div>';
            }
        ?>

        <div class="boxform-map">
            <?php include_once('boxform.layout.view.php');?>
        </div>

        <div class="map">
            <?php include_once('map.layout.view.php');?>
        </div>
        
        <div id="inputpanel">

            <div id='stat'>
            </div>

            <div id='action'>
                <?php include_once('input.layout.view.php');?>
            </div>

        </div>

</body>
</html>