<?php

class Database {
    private static $_host = "localhost";
    private static $_user = "root";
    private static $_pass = "root";
    private static $_db = "aitd";
    private static $_driver = "mysql";

    public static $_connection;

    public static function createConnexion() {
        self::$_connection = new PDO(
            self::$_driver
            .":host=".self::$_host
            .";dbname=".self::$_db, 
            self::$_user, 
            self::$_pass
        );
    }
}